SELECT sp.*
FROM XFDATA.dbo.SECURITY_PRICE sp
WHERE
  sp.SecurityID = 102886
  AND sp.Date BETWEEN '2011-01-01' AND '2011-06-01'
order by sp.Date